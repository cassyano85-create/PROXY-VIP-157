package com.proxyvip157.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    int blue = Color.rgb(41,182,246);
    int white = Color.WHITE;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showHome();
    }

    TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(12,12,12,12);
        return t;
    }

    void setup(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(20,24,20,20);
        root.setBackgroundColor(Color.rgb(5,9,20));
        setContentView(root);
        TextView heading = text("⚡ PROXY VIP 157 ⚡", 25, blue);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);
        TextView sub = text(title, 18, white);
        root.addView(sub);
        View line = new View(this);
        line.setBackgroundColor(blue);
        root.addView(line, new LinearLayout.LayoutParams(-1,2));
    }

    void addButton(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(white);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(12,48,76)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,12,0,4);
        root.addView(b,p);
        b.setOnClickListener(v -> action.run());
    }

    void showHome() {
        setup("PAINEL PRINCIPAL");
        root.addView(text("⚔️ SAMURAI AZUL ⚔️", 22, white));
        addButton("SENSIBILIDADE", () -> showSensitivity());
        addButton("CONFIGURAÇÕES", () -> showSettings());
        addButton("ANIMAÇÃO DO SAMURAI", () -> showAnimation());
        root.addView(text("Painel visual independente • VIP 157", 12, blue));
    }

    void showSensitivity() {
        setup("SENSIBILIDADE");
        String[] names = {"Geral","Ponto vermelho","Mira 2x","Mira 4x","AWM"};
        for (String n : names) {
            root.addView(text(n,16,white));
            SeekBar bar = new SeekBar(this);
            bar.setMax(200); bar.setProgress(100);
            root.addView(bar, new LinearLayout.LayoutParams(-1,-2));
        }
        root.addView(text("Ajustes demonstrativos: não alteram o Free Fire.",12,blue));
        addButton("VOLTAR", () -> showHome());
    }

    void showSettings() {
        setup("CONFIGURAÇÕES");
        Switch effects = new Switch(this);
        effects.setText("Efeitos elétricos");
        effects.setTextColor(white); effects.setChecked(true);
        root.addView(effects);
        addButton("VOLTAR", () -> showHome());
    }

    void showAnimation() {
        setup("ANIMAÇÃO DO SAMURAI");
        Switch anim = new Switch(this);
        anim.setText("Animação ativada");
        anim.setTextColor(white); anim.setChecked(true);
        root.addView(anim);
        addButton("VOLTAR", () -> showHome());
    }
}
